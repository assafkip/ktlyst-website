# Team Package Index

**Advisory:** Advisory Extraction
**Prepared for:** SPIE Switzerland
**Generated:** 2026-04-13
**Total files:** 52

## Deployment Tiers

Each artifact has a deployment tier based on risk and reversibility:

- **Tier 1 (Auto-deploy):** IOC blocklists, domain blocks, watchlists. Low risk, time-sensitive.
- **Tier 2 (Detection-as-Code):** Detection rules, hunt queries. Human reviews a diff.
- **Tier 3 (Human Approval):** Policies, assessments, emulation plans. High impact, review required.

## Distribution Guide

Forward this index to team leads. Each team opens their folder.

### CISO / VP Security
- `executive/board_brief.md` -- 1-page board brief, paste into the board pack
- `executive/risk_quantification.json` -- loss bands + probability (reads into board brief)
- This index file

### SOC / Detection Engineering (Unknown)
- `detection/sigma_rules/*.yml` -- convert with `sigma convert`

### Identity & Access Management (Unknown)
- `identity/scim_audit.kql` -- SCIM provisioning audit hunts (vendor-neutral)

### Email Security (Proofpoint (email gateway))
- `email/domains_blocklist.txt` -- one domain per line, import anywhere
- `email/proofpoint_url_defense.json` -- Proofpoint URL Defense custom block list + policy route

### Endpoint Security (Unknown (not inferable from DNS))
- `endpoint/visibility_assessment.md` -- READ THIS: what EDR sees vs doesn't

### Red / Purple Team
- `emulation/attack_navigator_layer.json` -- import into ATT&CK Navigator
- `emulation/atomic_tests/*.yaml` -- Atomic Red Team format
- `emulation/caldera_adversary.yml` -- Caldera adversary profile
- `emulation/emulation_plan.md` -- ordered attack steps
- `emulation/detection_gap_matrix.md` -- what's covered vs not

### GRC / Compliance
- `compliance/framework_mapping.csv` -- NIST CSF + applicable frameworks
- `compliance/evidence_bundle.json` -- audit-ready provenance
- `compliance/audit_trail_entry.json` -- single-record audit log entry (SOC 2 / ISO 27001)

### Raw IOC Data (Shared)
- `iocs/domains.csv` -- all IOC domains with source spans
- `iocs/domains.stix.json` -- STIX 2.1 bundle for TIP import
- `iocs/misp_event.json` -- MISP 2.4 Event JSON for MISP bulk import
- `iocs/full_ioc_list.json` -- full structured IOC list
